import os

from setuptools import find_packages, setup

setup(use_scm_version=True,)
