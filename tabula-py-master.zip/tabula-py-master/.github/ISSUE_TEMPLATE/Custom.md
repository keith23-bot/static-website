---
name: Question
about: The issue tracker is not for questions. Please use Stack Overflow or other
  resources for help writing tabula-py code.

---

THE ISSUE TRACKER IS NOT FOR QUESTIONS.

DO NOT CREATE A NEW ISSUE TO ASK A QUESTION.

IF YOU ARE HAVING PROBLEMS WITH YOUR TABULA-PY CODE, DO NOT ASK A QUESTION HERE.

Many tabula-py questions have been asked and answered on StackOverflow; see https://stackoverflow.com/search?q=tabula-py . You can ask questions there or on other websites.
